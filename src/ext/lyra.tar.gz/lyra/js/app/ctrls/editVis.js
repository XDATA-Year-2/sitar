vde.App.controller('EditVisCtrl', function($scope, Vis) {
  $scope.vis = Vis;
  $scope.props = Vis.properties;
});